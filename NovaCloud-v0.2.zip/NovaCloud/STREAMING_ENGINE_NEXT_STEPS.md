# NovaCloud — real streaming engine next steps

This project currently contains the Android UI and a Sunshine status/game-list client. It is not yet a streaming client.

## Required implementation work

1. Choose and pin a specific Moonlight client/protocol implementation and review its license obligations before redistributing it.
2. Implement `StreamEngine` in Kotlin, backed by the selected native/JNI or supported Android client components.
3. Add the actual pairing flow with the Sunshine host. Do not assume the web-admin password alone completes Moonlight pairing.
4. Render decoded frames in a `SurfaceView` or the rendering target required by the chosen engine.
5. Route audio output and lifecycle cleanup through Android audio APIs.
6. Map Bluetooth gamepad events and configurable on-screen touch controls to the protocol's input events.
7. Wire resolution, FPS and bitrate to real stream configuration rather than UI-only chips.
8. Test start/stop, app backgrounding, network loss/reconnect, certificate handling, and multiple Android devices against a real Sunshine host.

## Important limitation

Do not enable the Play action as if gameplay works until a real engine is installed and successfully paired. The current placeholder is intentional and prevents the UI from falsely claiming a stream is active.
