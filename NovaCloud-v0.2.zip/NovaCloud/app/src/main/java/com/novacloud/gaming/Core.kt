package com.novacloud.gaming

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import okhttp3.Credentials
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.security.MessageDigest
import java.security.cert.CertificateException
import java.security.cert.X509Certificate
import java.util.concurrent.TimeUnit
import javax.net.ssl.*

data class ServerConfig(val host: String, val port: Int, val user: String, val pass: String, val fp: String)
data class Game(val name: String)

sealed interface Link {
    object Checking : Link
    data class Online(val ms: Long) : Link
    object BadLogin : Link
    data class Offline(val why: String) : Link
}

fun quality(ms: Long) = when { ms < 30 -> "Excellent"; ms < 60 -> "Good"; ms < 120 -> "Fair"; else -> "Poor" }

/** Credentials live only in Android-Keystore-backed encrypted prefs. Nothing is hardcoded. */
class SecureStore(ctx: Context) {
    private val p = EncryptedSharedPreferences.create(
        ctx, "nova_secure",
        MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM)
    fun load(): ServerConfig? {
        val h = p.getString("host", null) ?: return null
        return ServerConfig(h, p.getInt("port", 47990), p.getString("user", "")!!, p.getString("pass", "")!!, p.getString("fp", "")!!)
    }
    fun save(c: ServerConfig) = p.edit().putString("host", c.host).putInt("port", c.port)
        .putString("user", c.user).putString("pass", c.pass).putString("fp", c.fp).apply()
    fun clear() = p.edit().clear().apply()
    fun list(k: String) = p.getString(k, "")!!.split("\n").filter { it.isNotBlank() }
    fun putList(k: String, v: List<String>) = p.edit().putString(k, v.joinToString("\n")).apply()
}

/** Talks to the owner's Sunshine server (https, basic auth) with certificate pinning (trust-on-first-use). */
class SunshineClient(private val c: ServerConfig) {
    private val tm = object : X509TrustManager {
        override fun checkClientTrusted(chain: Array<X509Certificate>, a: String) {}
        override fun checkServerTrusted(chain: Array<X509Certificate>, a: String) {
            if (!sha256(chain[0].encoded).equals(c.fp, true)) throw CertificateException("Pinned certificate mismatch")
        }
        override fun getAcceptedIssuers() = emptyArray<X509Certificate>()
    }
    private val http: OkHttpClient by lazy {
        val ctx = SSLContext.getInstance("TLS").apply { init(null, arrayOf(tm), null) }
        OkHttpClient.Builder().sslSocketFactory(ctx.socketFactory, tm)
            .hostnameVerifier { _, _ -> true } // identity is enforced by the pinned fingerprint
            .connectTimeout(4, TimeUnit.SECONDS).readTimeout(6, TimeUnit.SECONDS).build()
    }
    private fun call(path: String) = http.newCall(Request.Builder()
        .url("https://${c.host}:${c.port}$path").header("Authorization", Credentials.basic(c.user, c.pass)).build())

    /** Real round-trip to the server: online state, auth check, and latency in one request. */
    fun probe(): Link {
        val t = System.nanoTime()
        return try {
            call("/api/apps").execute().use { r ->
                when {
                    r.code == 401 -> Link.BadLogin
                    r.isSuccessful -> Link.Online((System.nanoTime() - t) / 1_000_000)
                    else -> Link.Offline("Server replied ${r.code}")
                }
            }
        } catch (e: Exception) { Link.Offline(friendly(e)) }
    }

    /** Games the owner added in the Sunshine web UI. */
    fun games(): List<Game> = call("/api/apps").execute().use { r ->
        if (!r.isSuccessful) emptyList() else {
            val a = JSONObject(r.body!!.string()).optJSONArray("apps")
            List(a?.length() ?: 0) { Game(a!!.getJSONObject(it).getString("name")) }
        }
    }

    companion object {
        fun sha256(b: ByteArray) = MessageDigest.getInstance("SHA-256").digest(b).joinToString("") { "%02X".format(it) }
        /** Handshake only (no data sent) so the owner can confirm and pin the certificate. */
        fun fingerprint(host: String, port: Int): String {
            val all = object : X509TrustManager {
                override fun checkClientTrusted(c: Array<X509Certificate>, a: String) {}
                override fun checkServerTrusted(c: Array<X509Certificate>, a: String) {}
                override fun getAcceptedIssuers() = emptyArray<X509Certificate>()
            }
            val ctx = SSLContext.getInstance("TLS").apply { init(null, arrayOf(all), null) }
            (ctx.socketFactory.createSocket(host, port) as SSLSocket).use { s ->
                s.soTimeout = 4000; s.startHandshake()
                return sha256(s.session.peerCertificates[0].encoded)
            }
        }
        fun friendly(e: Exception) = when (e) {
            is UnknownHostException -> "Can't find that address"
            is ConnectException, is SocketTimeoutException -> "PC not responding (is it on, with Sunshine running?)"
            is SSLException -> "Server certificate changed. Re-add the server if you trust it"
            else -> e.message ?: "Connection error"
        }
    }
}

data class StreamConfig(val height: Int, val fps: Int)

/**
 * Plug point for the video/audio/input engine (e.g. moonlight-common-c via JNI).
 * Until an implementation is assigned, the app refuses to pretend a game is running.
 */
interface StreamEngine {
    @Composable fun Content(game: Game, server: ServerConfig, cfg: StreamConfig)
    fun stop()
}
object StreamEngines { var current: StreamEngine? = null }
