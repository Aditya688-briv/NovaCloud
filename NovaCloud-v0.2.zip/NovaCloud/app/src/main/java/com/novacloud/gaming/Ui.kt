package com.novacloud.gaming

import android.content.Intent
import android.content.pm.ActivityInfo
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.*
import androidx.core.view.*
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.*

val Red = Color(0xFFE11D2E); val Ink = Color(0xFF000000); val Panel = Color(0xFF141414); val Ok = Color(0xFF22C55E)

class MainActivity : ComponentActivity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Red, background = Ink, surface = Panel, onPrimary = Color.White)) {
                Surface(Modifier.fillMaxSize(), color = Ink) { App() }
            }
        }
    }
}

@Composable fun App(vm: NovaVM = viewModel()) = when {
    vm.playing != null -> GameScreen(vm)
    vm.cfg == null || vm.showSetup -> SetupScreen(vm)
    else -> HomeScreen(vm)
}

@Composable fun SetupScreen(vm: NovaVM) {
    var host by remember { mutableStateOf("") }; var port by remember { mutableStateOf("47990") }
    var user by remember { mutableStateOf("") }; var pass by remember { mutableStateOf("") }
    var fp by remember { mutableStateOf<String?>(null) }; var err by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    Column(Modifier.fillMaxSize().padding(24.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Spacer(Modifier.height(32.dp))
        Text("NOVACLOUD", color = Red, fontSize = 28.sp, fontWeight = FontWeight.Black)
        Text("Connect to your own gaming PC (Sunshine server)", color = Color.White)
        OutlinedTextField(host, { host = it; fp = null }, label = { Text("Server address") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(port, { port = it; fp = null }, label = { Text("Web UI port") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(user, { user = it }, label = { Text("Sunshine username") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(pass, { pass = it }, label = { Text("Sunshine password") }, singleLine = true,
            visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
        val ready = host.isNotBlank() && user.isNotBlank() && pass.isNotBlank() && port.toIntOrNull() != null
        if (fp == null) Button(enabled = ready && !busy, modifier = Modifier.fillMaxWidth(), onClick = {
            busy = true; err = null
            scope.launch {
                runCatching { withContext(Dispatchers.IO) { SunshineClient.fingerprint(host.trim(), port.toInt()) } }
                    .onSuccess { fp = it }.onFailure { err = "Could not reach server: ${it.message}" }
                busy = false
            }
        }) { Text(if (busy) "Checking…" else "Verify server") }
        else {
            Text("First connection pins this certificate. Do this on a network you trust.", color = Color.Gray, fontSize = 12.sp)
            Text(fp!!.chunked(2).joinToString(":"), color = Color.White, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
            Button(modifier = Modifier.fillMaxWidth(), onClick = {
                vm.save(ServerConfig(host.trim(), port.toInt(), user.trim(), pass, fp!!))
            }) { Text("Trust & save") }
        }
        err?.let { Text(it, color = Red) }
    }
}

@Composable fun HomeScreen(vm: NovaVM) {
    var q by remember { mutableStateOf("") }
    val ctx = LocalContext.current
    val shown = vm.games.filter { it.name.contains(q, true) }
    LazyColumn(contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
        item { Text("Welcome to NovaCloud", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Black) }
        item { OutlinedTextField(q, { q = it }, placeholder = { Text("Search games") }, singleLine = true, modifier = Modifier.fillMaxWidth()) }
        item { StatusCard(vm) }
        item { Button(modifier = Modifier.fillMaxWidth().height(52.dp), onClick = { vm.monitor() }) { Text("Connect to Gaming PC") } }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { vm.cfg?.let { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://${it.host}:${it.port}"))) } }) { Text("Add games") }
                OutlinedButton(onClick = { vm.refreshGames() }) { Text("Refresh") }
                TextButton(onClick = { vm.signOut() }) { Text("Sign out", color = Color.Gray) }
            }
        }
        shelf("Recently Played", vm.recent.mapNotNull { n -> shown.find { it.name == n } }, vm, "Nothing played yet")
        shelf("My Games", shown, vm, if (vm.link is Link.Online) "No games on your server yet. Tap Add games." else "Connect to your PC to see your games")
        shelf("Featured Games", shown.filter { it.name in vm.favs }, vm, "Tap ☆ on a game to feature it")
    }
}

fun LazyListScope.shelf(title: String, list: List<Game>, vm: NovaVM, empty: String) = item {
    Column(Modifier.animateContentSize()) {
        Text(title, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        if (list.isEmpty()) Text(empty, color = Color.Gray, fontSize = 13.sp)
        else LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) { items(list) { GameCard(it, vm) } }
    }
}

@Composable fun StatusCard(vm: NovaVM) {
    val (label, color) = when (val l = vm.link) {
        is Link.Online -> "Server online · ${l.ms} ms · ${quality(l.ms)}" to Ok
        Link.Checking -> "Checking server…" to Color.Gray
        Link.BadLogin -> "Login rejected. Sign out and re-enter credentials" to Red
        is Link.Offline -> "Offline: ${l.why}. Retrying…" to Red
    }
    val dot by animateColorAsState(color, label = "dot")
    Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(10.dp).background(dot, CircleShape)); Spacer(Modifier.width(12.dp)); Text(label, color = Color.White)
    }
}

@Composable fun GameCard(g: Game, vm: NovaVM) {
    val online = vm.link is Link.Online; val fav = g.name in vm.favs
    Column(Modifier.width(160.dp).clip(RoundedCornerShape(16.dp)).background(Panel)) {
        Box(Modifier.fillMaxWidth().height(110.dp).background(Brush.linearGradient(listOf(Color(0xFF3A0008), Ink))), contentAlignment = Alignment.Center) {
            Text(g.name.take(1).uppercase(), color = Red, fontSize = 44.sp, fontWeight = FontWeight.Black)
            Text(if (fav) "★" else "☆", color = Color.White, modifier = Modifier.align(Alignment.TopEnd).clickable { vm.toggleFav(g) }.padding(10.dp))
        }
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(g.name, color = Color.White, maxLines = 1, fontWeight = FontWeight.Bold)
            Text(if (online) "Server: ready" else "Server: offline", color = if (online) Ok else Color.Gray, fontSize = 12.sp)
            Text("Controller · Touch", color = Color.Gray, fontSize = 11.sp)
            Button(onClick = { vm.play(g) }, enabled = online, modifier = Modifier.fillMaxWidth()) { Text("Play") }
        }
    }
}

@Composable fun GameScreen(vm: NovaVM) {
    val act = LocalContext.current as ComponentActivity
    DisposableEffect(Unit) {
        act.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        val c = WindowCompat.getInsetsController(act.window, act.window.decorView)
        c.hide(WindowInsetsCompat.Type.systemBars())
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        onDispose { act.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED; c.show(WindowInsetsCompat.Type.systemBars()) }
    }
    BackHandler { vm.exitGame() }
    var height by remember { mutableStateOf(1080) }
    val game = vm.playing!!; val engine = StreamEngines.current; val server = vm.cfg!!
    Box(Modifier.fillMaxSize().background(Ink)) {
        if (engine == null) Column(Modifier.align(Alignment.Center).padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("Streaming engine not linked", color = Red, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text("This build reaches your server but can't decode video yet, so no game is running. See README section 5.", color = Color.White)
        } else engine.Content(game, server, StreamConfig(height, 60))
        Row(Modifier.align(Alignment.TopStart).padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Button(onClick = { vm.exitGame() }) { Text("Exit game") }
            listOf(720, 1080, 1440).forEach { h -> FilterChip(height == h, { height = h }, label = { Text("${h}p") }) }
        }
        if (vm.link !is Link.Online) Text("Connection lost. Reconnecting…", color = Color.White,
            modifier = Modifier.align(Alignment.TopEnd).padding(16.dp).background(Red, RoundedCornerShape(8.dp)).padding(8.dp))
    }
}
