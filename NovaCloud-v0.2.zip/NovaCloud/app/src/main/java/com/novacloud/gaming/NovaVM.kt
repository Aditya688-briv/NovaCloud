package com.novacloud.gaming

import android.app.Application
import androidx.compose.runtime.*
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.*

class NovaVM(app: Application) : AndroidViewModel(app) {
    private val store = SecureStore(app)
    var cfg by mutableStateOf(store.load()); private set
    var link by mutableStateOf<Link>(Link.Checking); private set
    var games by mutableStateOf(listOf<Game>()); private set
    var recent by mutableStateOf(store.list("recent")); private set
    var favs by mutableStateOf(store.list("favs")); private set
    var playing by mutableStateOf<Game?>(null)
    var showSetup by mutableStateOf(false)
    private var job: Job? = null

    init { monitor() }

    /** Polls forever (no session timer). Keeps retrying while offline, which is the auto-reconnect. */
    fun monitor() {
        job?.cancel()
        val c = cfg ?: return
        link = Link.Checking
        job = viewModelScope.launch(Dispatchers.IO) {
            val api = SunshineClient(c); var was = false
            while (isActive) {
                val l = api.probe(); link = l
                if (l is Link.Online && !was) games = runCatching { api.games() }.getOrDefault(games)
                was = l is Link.Online
                delay(if (l is Link.Online) 5000 else 3000)
            }
        }
    }
    fun refreshGames() { val c = cfg ?: return; viewModelScope.launch(Dispatchers.IO) { games = runCatching { SunshineClient(c).games() }.getOrDefault(games) } }
    fun save(c: ServerConfig) { store.save(c); cfg = c; showSetup = false; monitor() }
    fun signOut() { job?.cancel(); store.clear(); cfg = null; games = emptyList(); recent = emptyList(); favs = emptyList() }
    fun toggleFav(g: Game) { favs = if (g.name in favs) favs - g.name else favs + g.name; store.putList("favs", favs) }
    fun play(g: Game) {
        if (link !is Link.Online) return
        recent = (listOf(g.name) + recent.filter { it != g.name }).take(8); store.putList("recent", recent)
        playing = g
    }
    fun exitGame() { StreamEngines.current?.stop(); playing = null }
}
