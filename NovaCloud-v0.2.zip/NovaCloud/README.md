# NovaCloud Gaming (prototype — streaming engine still required)

Private Android client for streaming games from **your own** Windows/Linux PC. Kotlin + Jetpack Compose. No ads, no timer, no subscription.

## Architecture
- **Backend = your PC running [Sunshine](https://github.com/LizardByte/Sunshine)** (open-source game-stream host). The app contains no server code.
- **Frontend = this app.** `SunshineClient` makes real HTTPS calls: online check, auth check, latency, game list. The Play button is disabled unless the server answered.
- **Security:** credentials are stored in Keystore-backed EncryptedSharedPreferences, never in code. The server certificate is pinned on first connect (trust-on-first-use) and cleartext traffic is disabled.
- **Streaming:** `StreamEngine` interface (video, audio, controller, touch). Not linked yet, and the app says so instead of faking gameplay.

## 1. Set up the gaming PC
1. Install Sunshine on the PC, open `https://localhost:47990`, and create the admin username/password.
2. Add your games under **Applications** (this is the "add games" step; you need legitimate licenses for each).
3. Reach the PC from your phone safely: install **Tailscale** on both (recommended) rather than port-forwarding. Use the PC's Tailscale IP as the server address.
4. Keep the PC awake (power plan: never sleep) and plugged in.

## 2. Build the app
Open this folder in Android Studio (JDK 17, Android SDK 34), let Gradle sync, then run on a device. This project was not compiled in the current environment, so a successful build has not been verified. If Gradle reports an error, use the first actual error message to guide the fix.

## 3. Connect
Launch, enter address, port 47990, Sunshine credentials, tap **Verify server**, then **Trust & save**. Home shows status, latency and your games.

## 4. Controls
Bluetooth controllers and touch overlays are handled by the engine in section 5.

## 5. Streaming engine status (required to actually play)
**Not implemented in this prototype.** `StreamEngine` is only an interface; `StreamEngines.current` remains `null`, so the game screen intentionally displays “Streaming engine not linked”. This build does not send a streaming handshake, decode video, play audio, or send controller/touch input.

To implement real streaming, integrate a compatible Moonlight client engine. The usual native route is `moonlight-common-c` through JNI, plus Android rendering/audio/input code. This is a substantial native integration, not just a Gradle dependency. It needs pairing, session negotiation, video decode to a `SurfaceView`, Opus audio, controller/touch events, resolution/bitrate settings, and lifecycle/cleanup handling. Follow the official Moonlight project documentation and pin a specific upstream revision; do not copy arbitrary binaries from untrusted sources. Moonlight components may be GPLv3-licensed, so review license and source-distribution obligations before publishing the app.

**Do not treat this project as gameplay-ready until the streaming engine is integrated and tested on a real device against a Sunshine host.**

## 6. "Unlimited" sessions
The app has no session timer. A session lasts as long as your PC is on, Sunshine is running and the network holds. Real limits: PC hardware and power, your upload bandwidth, and any cloud host's limits or charges (a rented cloud GPU bills by the hour).

## Not included yet
Cover art, on-screen touch layout editor, biometric app lock, Wake-on-LAN.


## Build note for v0.2
Added the explicit Compose Animation dependency used by `animateContentSize` and `animateColorAsState`, and incremented the app version. This is a build-configuration improvement only; it does not add the missing streaming engine.
